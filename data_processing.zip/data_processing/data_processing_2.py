import os
import json
import random

input_dir = "data/annotation/"
file_name_list = os.listdir(input_dir)
file_name_list = [int(_.split(".")[0]) for _ in file_name_list]


# 切分正负样本
random.shuffle(file_name_list)
train_file_index = file_name_list[:int(len(file_name_list)*0.9)]
test_file_index = file_name_list[int(len(file_name_list)*0.9):]

# 写入文件中
with open("data/train_file", "w", encoding="utf8") as f:
    for line in train_file_index:
        f.write(str(line) + "\n")

with open("data/test_file", "w", encoding="utf8") as f:
    for line in test_file_index:
        f.write(str(line) + "\n")
