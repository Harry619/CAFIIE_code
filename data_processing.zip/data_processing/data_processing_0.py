# -*- coding: utf-8 -*-
import json
import os
from stanfordcorenlp import StanfordCoreNLP

nlp = StanfordCoreNLP(r"stanford-corenlp-full-2018-10-05")


def parse_doc(idx, input_path, output_path):
    try:
        # 读取文件全信息, 取出其中内容部分
        with open(input_path, encoding="utf8") as f:
            doc = json.load(f)

        content_line = doc["content"]

        # 进行nlp 处理
        ann_output = nlp.annotate(
            content_line,
            properties={
                'timeout': '50000',
                'annotators': 'tokenize, pos, ner, parse, depparse, dcoref',
                #   'outputFormat': 'json'
            })
        # 为了保持一致
        ann_output = json.loads(ann_output)
        ann_output["docId"] = str(idx) + ".content"
        with open(output_path, "w", encoding="utf8") as p:
            json.dump(ann_output, p, indent=4)
            # p.write(ann_output)
    except:
        print("idx" + str(idx) + "have prob")


input_dir = "data/annotation/"
output_dir = "data/content/"
# demo
# parse_doc("4", "data/annotation/4.json", "data/content/4.content.json")

# all
file_name_list = os.listdir(input_dir)
file_name_list = [int(_.split(".")[0]) for _ in file_name_list]
file_name_list.sort()
for fi in file_name_list:
    infile = input_dir + "/" + str(fi) + ".json"
    outfile = output_dir + "/" + str(fi) + ".content.json"
    parse_doc(fi, infile, outfile)
