import os
import json


# 取停用词
stop_file = "data/stop_word.txt"
stop_list = []
with open(stop_file, encoding="utf8") as f:
    for line in f:
        stop_list.append(line.strip())

def process_file(in_file, in_file_token, out_file):

    
    # 取token
    word_list = []
    with open(in_file_token, encoding="utf8") as f:
        info = json.load(f)
        for sent in info["sentences"]:
            tokens = sent["tokens"]
            for token in tokens:
                # 去掉停用词
                if token["originalText"].lower() in stop_list:
                    continue
                tmp = [
                    token["originalText"], token["characterOffsetBegin"],
                    token["characterOffsetEnd"]
                ]
                word_list.append(tmp)
            word_list.append(["=|=", -1, -1])

    # 取nug等信息
    nug_list = []
    with open(in_file, encoding="utf8") as f:
        info = json.load(f)
        hoppers = info["cyberevent"]["hopper"]
        for hopper in hoppers:
            index = hopper["index"]
            events = hopper["events"]
            for event in events:
                nugget = event.get("nugget", None)
                if nugget is None:
                    continue
                realis = event["realis"]
                nugget = event["nugget"]

                subtype = event["subtype"]

                nug_list.append([
                    nugget["startOffset"], nugget["endOffset"], subtype, "O",
                    realis, "(" + str(index) + ")"
                ])
                argument = event.get("argument", None)
                if argument is None:
                    continue
                for argu in argument:
                    nug_list.append([
                        argu["startOffset"], argu["endOffset"], argu["type"],
                        argu["role"]["type"], "O", "-"
                    ])

    # 组装
    with open(out_file, "w", encoding="utf8") as f:
        result = []
        for word in word_list:
            result.append([word[0], word[1], "O", "O", "O", "-"])

        # 修正
        for nug in nug_list:
            count = 0
            for ind, res in enumerate(result):
                if res[1] >= nug[0] and res[1] < nug[1]:
                    if count == 0:
                        if nug[2] != "O":
                            result[ind][2] = "B-" + nug[2]
                        if nug[3] != "O":
                            result[ind][3] = "B-" + nug[3]
                        count += 1
                    else:
                        if nug[2] != "O":
                            result[ind][2] = "I-" + nug[2]
                        if nug[3] != "O":
                            result[ind][3] = "I-" + nug[3]

                    result[ind][4] = nug[4]
                    result[ind][5] = nug[5]

        for res in result:
            if res[0] == "=|=":
                f.write("\n")
                continue
            res[1] = str(res[1])
            f.write("\t".join(res) + "\n")



input_dir = "data/annotation/"
input_token = "data/content/"
output_dir = "data/content/"
# process_file("data/annotation/4.json", "data/content/4.content.json",
#              "data/label/4.content.nostop.label")

# all
file_name_list = os.listdir(input_dir)
file_name_list = [int(_.split(".")[0]) for _ in file_name_list]
file_name_list.sort()
for fi in file_name_list:
    infile = input_dir + str(fi) + ".json"
    infile_token = input_token + str(fi) + ".content.json"
    outputfile = output_dir + str(fi) + ".content.nostop.label"
    process_file(infile, infile_token, outputfile)
