import os
import json
import random
from sklearn.model_selection import KFold

input_dir = "data/annotation/"
file_name_list = os.listdir(input_dir)
file_name_list = [int(_.split(".")[0]) for _ in file_name_list]

kf = KFold(n_splits=5,shuffle=False)

for k, (train_index, test_index) in enumerate(kf.split(file_name_list)):
    # # 写入文件中
    with open("data/train_file_" + str(k), "w", encoding="utf8") as f:
        for index in train_index:
            f.write(str(file_name_list[index]) + "\n")

    with open("data/test_file_" + str(k), "w", encoding="utf8") as f:
        for index in test_index:
            f.write(str(file_name_list[index]) + "\n")
    
# # 切分正负样本
# random.shuffle(file_name_list)
# train_file_index = file_name_list[:int(len(file_name_list)*0.9)]
# test_file_index = file_name_list[int(len(file_name_list)*0.9):]

# # 写入文件中
# with open("data/train_file", "w", encoding="utf8") as f:
#     for line in train_file_index:
#         f.write(str(line) + "\n")

# with open("data/test_file", "w", encoding="utf8") as f:
#     for line in test_file_index:
#         f.write(str(line) + "\n")
