"""Event nugget and argument detection system
   build a neural classifier (Bi-LSTM-CRF) (w/attention for Argument detection)
   Input: file '.content' one token per line
   Output: predicted file with classification score
   可以利用训练好的模型文件：
   Model_Path = "nug_arg_det_savemodel_actirelu.h5"
   仅仅对测试集输出的准确率，可以得到acc=(0.9397,1+1+1), (0.73,1), (0.71,2),(0.39,1)
   """
import gc

from keras.losses import categorical_crossentropy
# 固定各种随机状态，以方便多次运行程序，观察算法模型的输出，利于对比性能优劣
from numpy.random import seed

seed(1)
from tensorflow import set_random_seed
set_random_seed(1)

import random as rn

rn.seed(1)
import os

os.environ['PYTHONHASHSEED'] = '0'
import sys

sys.path.append('../../../../')

import utils
import parseJsontoFeatures
import x2index
import prepare
import layers
import report

import argparse

import FM


from keras.models import Model, load_model
from keras.layers import Dense, LSTM, Input, Bidirectional, Embedding, Concatenate
from keras.layers import Dropout
from keras.optimizers import Adam

from keras_contrib.layers import CRF
from keras_contrib.metrics import crf_accuracy

from keras_self_attention import SeqSelfAttention
# import tensorflow as tf

import warnings

warnings.filterwarnings('ignore', category=FutureWarning)

# sess = tf.Session(config=tf.ConfigProto(log_device_placement=True))

NuggetList10 = [
    "B-Phishing", "I-Phishing", "B-DiscoverVulnerability",
    "B-Databreach", "I-Databreach", "I-DiscoverVulnerability",
    "B-PatchVulnerability", "I-PatchVulnerability", "B-Ransom", "I-Ransom"
]
ArgumentList = [
    "B-Website", "I-Website", "B-Patch", "I-Patch", "B-Data", "I-Data",
    "B-Organization", "I-Organization", "B-Version", "I-Version",
    "B-Software", "I-Software", "B-Time", "I-Time", "B-GPE", "I-GPE",
    "B-Person", "I-Person", "B-Vulnerability", "I-Vulnerability",
    "B-System", "I-System", "B-Tool", "I-Tool", "B-Money", "I-Money",
    "B-Device", "I-Device", "I-PaymentMethod", "B-PaymentMethod",
    "B-Number",  "I-Number", "B-PII", "I-PII", "B-Malware", "I-Malware",
    "B-Capabilities","I-Capabilities", "B-Purpose" ,"I-Purpose",
    "B-File", "I-File",  "B-CVE", "I-CVE",
]

Total_Words_Counter = 0
Total_Sents_Counter = 0

def process_input(fname, onlynugget, onlyarg):
    """ label file split into data and label
        Input:  filename-list of file to be processed
                onlynugget-set to true if detect nuggets
                onlyarg-set to true if detect arguments
        Output: sentence-for each sentence is list of dict of surface word of all files [[{'originalText': ,}]]
                # 每个句子是所有文件的字面词的字典列表
                label-list of label
    """
    content = utils.readFileEncode(fname, 'utf8')
    lines = content.split('\n')[:-1]
    # 在主函数调用中，处理的对象是#.content.nostop.label,此处以换行为分隔，取出所有的行
    # 空格行是不同句子的分隔标志，lines[i]<=3时，判定为空格行，
    # 将每个句子处理好的 sent=[{'originalText':单词}, {‘offset’: 起始位置},...]
    # 与 label=['B-Person', 'B-Databreach', ...] 写入到sents与labels中，作为一个文件的文本数据汇总
    sentences = []
    labels = []
    sent = []
    label = []
    global Total_Words_Counter
    global Total_Sents_Counter
    words_counter = 0
    sents_counter = 0
    # counter += len(lines[i])  # 计数器
    for i in range(len(lines)):
        if len(lines[i]) > 3:
            words_counter += 1  # 计数器
            words = lines[i].split('\t')
            word = {'originalText': words[0], 'offset': int(words[1])}
            sent.append(word)
            if onlynugget:
                if words[2] in NuggetList10:
                    label.append(words[2])
                else:
                    label.append('O')
            elif onlyarg:
                if words[2] in ArgumentList:

                    if 'Software' in words[2]:
                        label.append(words[2][0:2] + 'System')
                    else:
                        label.append(words[2])
                else:
                    label.append('O')
        else:
            if len(sent) > 0 and len(label) > 0:
                sents_counter += 1
                sentences.append(sent)
                labels.append(label)
                sent = []
                label = []
            elif len(sent) == 0 and i < len(lines) - 1:
                sentences.append([])
                labels.append([])
    print(f"当前读取处理的文本是{fname}，该文本的单词数据量有{words_counter}")
    Total_Words_Counter += words_counter
    Total_Sents_Counter += sents_counter

    print(f"当前处理的文本是{fname}，汇总存储的单词总量有{Total_Words_Counter},句子总量有{Total_Sents_Counter}")

    return sentences, labels




def build_model(allidx, MAX_LENGTH, onlyArg,
                epochs, learning_rate, dropout):
    """ build model for event detection task
    Input:  allidx-dict of index of word, label, features, extra features
            MAX_LENGTH-length of sentence
            classweight-weight by frequency for each class
            onlyArg-set true if detect argument
            onlyNugget-set true if detect nugget
            flags-collection of flags (use/not use) for feature sets
            w2v-choice of word vector to be used
            attn-choice of attention to be used
    Output: model and print out model summary
"""
    # 指定各项特征的索引，赋值给变量名
    wordidx, labelidx, featuresidx, extraidx = allidx
    posidx, neridx, depidx, distanceidx, chnkidx, wikineridx, dbpedianeridx, subneridx = featuresidx
    # 获得网络输入层的输入规模数量
    main_input = Input(shape=(MAX_LENGTH, ), name='main_input', dtype='int32')
    inputNodes = [main_input]
    # 导入单词嵌入的预训练模型
    w2vmodel = "../embeddings/Domain-Word2vec.model"
    # 使用预训练嵌入模型，对原始文本做词嵌入，得到词向量
    # 疑问：使用的是原始文本的单词索引，而非单词，预训练模型怎么确定原始文本，仅通过原始文本的单词索引也能嵌入？？
    embedding_matrix, EMBEDDING_DIM, vocabulary_size = prepare.wv_embedded(
        wordidx, w2vmodel)

    x = Embedding(output_dim=EMBEDDING_DIM,
                  weights=[embedding_matrix],
                  input_dim=vocabulary_size,
                  input_length=MAX_LENGTH,
                  mask_zero=False)(main_input)
    numnode = int(EMBEDDING_DIM / 2)

    # pos embedding
    inputNodes, pos_layer = layers.embedlayer(inputNodes, "pos_input", posidx,
                                              MAX_LENGTH)
    x = Concatenate()([x, pos_layer])
    numnode += int(len(posidx) / 2)

    # ner embedding
    inputNodes, ner_layer = layers.embedlayer(inputNodes, "ner_input", neridx,
                                              MAX_LENGTH)
    x = Concatenate()([x, ner_layer])
    numnode += int(len(neridx) / 2)

    inputNodes, wikiner_layer = layers.embedlayer(inputNodes, "wikiner_input",
                                                  wikineridx, MAX_LENGTH)
    x = Concatenate()([x, wikiner_layer])
    numnode += int(len(wikineridx) / 2)

    inputNodes, dbpedianer_layer = layers.embedlayer(inputNodes,
                                                     "dbpedianer_input",
                                                     dbpedianeridx, MAX_LENGTH)
    x = Concatenate()([x, dbpedianer_layer])
    numnode += int(len(dbpedianeridx) / 2)

    # dep embedding
    inputNodes, dep0_layer = layers.embedlayer(inputNodes, "dep0_input",
                                               depidx, MAX_LENGTH)
    x = Concatenate()([x, dep0_layer])
    numnode += int(len(depidx) / 2)

    inputNodes, dep1_layer = layers.embedlayer(inputNodes, "dep1_input",
                                               depidx, MAX_LENGTH)
    x = Concatenate()([x, dep1_layer])
    numnode += int(len(depidx) / 2)

    inputNodes, dep2_layer = layers.embedlayer(inputNodes, "dep2_input",
                                               depidx, MAX_LENGTH)
    x = Concatenate()([x, dep2_layer])
    numnode += int(len(depidx) / 2)

    # chnk embedding
    inputNodes, lvl_layer = layers.embedlayer(inputNodes, "lvl_input",
                                              distanceidx, MAX_LENGTH)
    x = Concatenate()([x, lvl_layer])
    numnode += int(len(distanceidx) / 2)

    inputNodes, chnk_layer = layers.embedlayer(inputNodes, "chnk_input",
                                               chnkidx, MAX_LENGTH)
    x = Concatenate()([x, chnk_layer])
    numnode += int(len(chnkidx) / 2)

    # wikiclass embedding
    inputNodes, subner_layer = layers.embedlayer(inputNodes, "subner_input",
                                                 subneridx, MAX_LENGTH)
    x = Concatenate()([x, subner_layer])
    numnode += int(len(subneridx) / 2)
    # 关于以上多维嵌入的疑惑：inputNodes在不同类型嵌入的过程中，输入的inputNodes会叠加当前最大长度的形状，
    # append到输出的inputNodes中，导致inputNodes在本应并列的多维嵌入中，inputNodes数值却不断增大，
    # 虽然搞不清楚影响在哪里，但总感觉不对劲，这就像不同层在叠加，而非并列
    # 但从论文的论述角度反观代码，这里可能就是一个类似于计数器，并不会在每类嵌入起作用，
    # 每类嵌入维度起作用的，可能就是MAX_LENGTH参数
    if onlyArg:
        neartrigger_input = Input(shape=(MAX_LENGTH, ),
                                  name='neartrigger_input',
                                  dtype='int32')
        inputNodes.append(neartrigger_input)
        neartrigger_layer = Embedding(output_dim=EMBEDDING_DIM, weights=[embedding_matrix],input_dim=vocabulary_size, \
                                      input_length=MAX_LENGTH, mask_zero=False)(neartrigger_input)
        x = Concatenate()([x, neartrigger_layer])
        numnode += 50
        inputNodes, x, numnode = layers.extralayer(inputNodes, x, numnode,
                                                   extraidx, featuresidx,
                                                   MAX_LENGTH)

    lstm_out = Bidirectional(LSTM(numnode, dropout=dropout,    # 0.3,
                                  return_sequences=True))(x)
    numnode = int((numnode + len(labelidx)) * 2 / 3)

    if onlyArg:
        lstm_out = SeqSelfAttention(attention_activation='tanh',
                                    attention_width=5)(lstm_out)

    lstm_out = Dropout(dropout)(lstm_out)    # 0.3
    out = Dense(numnode, activation='tanh')(lstm_out)

    # main_output = Dense(len(labelidx))(out)
    # loss = categorical_crossentropy
    # acc = ['accuracy']

    crf = CRF(len(labelidx), sparse_target=False)  # CRF layer
    main_output = crf(out)
    loss = crf.loss_function   # crf_loss  # categorical_crossentropy  #crf.loss_function
    acc = [crf_accuracy]

    model = Model(inputs=inputNodes, outputs=main_output)
    if epochs < 6:
        print(f"当前程序运行的epochs是{epochs}")
        model.compile(loss=loss, optimizer=Adam(learning_rate), metrics=acc)   # 0.022
    else:
        print(f"当前程序运行的epochs是{epochs}")
        model.compile(loss=loss, optimizer=Adam(learning_rate), metrics=acc)

    model.summary()

    return model
    ArguParser(Nug_or_Arg, Shuf, Epochs, Batch_size,
                        learning_rate, dropout, Modelpath)

def ArguParser(Nug_or_Arg, Shuf, Epochs, Batch_size,
               learning_rate, dropout):
    parser = argparse.ArgumentParser()
    parser.add_argument("-trainfile",
        default="../data/train_file_copy",
        # default="../data/train_file-part00",
        help="train file list",)
    parser.add_argument("-testfile",
        default="../data/test_file",
        # default="../data/test_file_copy",
        help="test file list",)
    parser.add_argument("-directory",
        default="../data/content/",
        help="directory contained train and test files",)
    parser.add_argument("-epochs",
                        default=Epochs,
                        help="maximum number of epochs for training",
                        type=int)
    # parser.add_argument("-Act",
    #                     default=Act,
    #                     help="Activation",
    #                     type=int)
    # parser.add_argument("-Shuf",
    #                     default=Shuf,
    #                     help="Shuffle",
    #                     type=int)
    parser.add_argument("-Batch_size",
                        default=Batch_size,
                        help="batch_size",
                        type=int)
    parser.add_argument("-learning_rate",
                        default=learning_rate,
                        help="backward learning rate for training loss",
                        type=int)
    parser.add_argument("-dropout",
                        default=dropout,
                        help="the neuro dropout percent in neuro network",
                        type=int)
    # parser.add_argument("-Modelpath",
    #                     default=Modelpath,
    #                     help="Modelpath",
    #                     type=int)
    if Nug_or_Arg =="Nug":
        parser.add_argument("-nugget",
                        default=True,
                        help="set this options for nugget detection",
                        action="store_true")
        parser.add_argument("-argument",
                        default=False,
                        help="set this options for argument detection",
                        action="store_true")
    elif Nug_or_Arg =="Arg":
        parser.add_argument("-nugget",
                        default=False,
                        help="set this options for nugget detection",
                        action="store_true")
        parser.add_argument("-argument",
                        default=True,
                        help="set this options for argument detection",
                        action="store_true")
    else:
        print("主程序的'Nug_or_Arg'字段赋值错误，只能输入'Nug'或'Arg'!")
    parser.add_argument("-outputfile",
                        default="../data/label/arg_m1",
                        help="specify output predict file name")
    return parser


def main(argv, Train_or_Load_or_Test_Model, Nug_or_Arg, Act, Shuf,
         Epochs, Batch_size, learning_rate, dropout, Modelpath):
         # Train_Model_Save, Test_Model_Read
    global modelpath
    parser = ArguParser(Nug_or_Arg, Shuf, Epochs, Batch_size,
                        learning_rate, dropout)
    args = parser.parse_args()
    i=1

    if args.nugget:
        parseOpt = 'trigger'
    elif args.argument:
        parseOpt = 'argument'
        # useextra = True
    if Shuf == 'no':
        shuffle = 'False'
    else:
        shuffle = 'True'

    filechange_position = {}
    if args.trainfile != '' and args.testfile != '':
        # ######## read train files #############
        lines = utils.readFile(args.trainfile)
        listfile = lines.split('\n')[:-1]
        trainset = []
        train_labels = []
        for fname in listfile:
            filename = args.directory + fname + '.content.nostop.label'
            fsentences, flabels = process_input(filename, args.nugget,
                                                args.argument)

            jfile = fname + '.content.json'
            jfile = os.path.join(args.directory, jfile)

            if os.path.isfile(jfile):
                # print("start --> here", jfile)
                each_sent_feature = parseJsontoFeatures.parse(jfile,
                                                              filename,
                                                              options=parseOpt)
                # print("end --> here", jfile, "已打印的文章数为：{}".format(i))
                i += 1
                gc.collect()
            else:
                print('no content.json file' % jfile)
                continue

            trainset = prepare.features(fsentences, each_sent_feature,
                                        trainset, args.argument, args.nugget)

            for k in flabels:
                train_labels.append(k)

        # ####### read test files ##############
        lines = utils.readFile(args.testfile)
        listfile = lines.split('\n')[:-1]
        testset = []
        test_labels = []
        fileth = 0

        for fname in listfile:
            filechange_position[fileth] = {}
            filechange_position[fileth]['position'] = len(testset)
            filechange_position[fileth]['filename'] = fname
            fileth += 1
            filename = args.directory + fname + '.content.nostop.label'
            fsentences, flabels = process_input(filename, args.nugget,
                                                args.argument)
            # if fname == "22":
            #     for i in range (len(fsentences)):
            #         print(fsentences[i])
            #         print(len(flabels[i]))
            #         print("=======")

            jfile = fname + '.content.json'
            jfile = os.path.join(args.directory, jfile)
            if os.path.isfile(jfile):
                each_sent_feature = parseJsontoFeatures.parse(jfile,
                                                              filename,
                                                              options=parseOpt)
            else:
                print('no content.json file' % jfile)
                continue

            testset = prepare.features(fsentences, each_sent_feature, testset,
                                       args.argument, args.nugget)

            # for i in range(len(testset)):
            #     for j in range(len(testset[i])):
            #         sampleword = testset[i][j]['text']
            #         print(i, "-|-", j, "---", sampleword)
            # exit(1)
            for k in flabels:
                test_labels.append(k)

        # 作者 论文中提到的 linguistic features sets
        # (1) 每个单词的词性
        # (2) CoreNLP和DBpedia中的实体类型
        # (3) 实体在Wikidata中的相关类型
        # (4) 句子中提取的一组句法依赖关系
        # (5) 句法特征
        # 参数特征与其相似。
        wordidx = x2index.word2idx(trainset)
        labelidx = x2index.label2idx(train_labels, True)
        posidx = x2index.pos2idx(trainset)
        neridx = x2index.ner2idx(trainset)
        wikineridx = x2index.wikiner2idx(trainset)
        dbpedianeridx = x2index.dbpedianer2idx(trainset)
        depidx = x2index.dep2idx(trainset)
        chnkidx = x2index.chnk2idx(trainset)
        subneridx = x2index.subner2idx(trainset)
        distanceidx = x2index.distance2idx()
        extraidx = {}

        if args.argument:  # 参数特征会额外增加下面这些
            eventidx = x2index.event2idx(trainset)
            positionidx = x2index.position2idx(trainset)
            rootparseidx = x2index.rootparseTrggr2idx(trainset)
            yesnoidx = x2index.yesno2idx()
            extraidx = (eventidx, positionidx, rootparseidx, yesnoidx)

        Featuresidx = (posidx, neridx, depidx, distanceidx, chnkidx,
                       wikineridx, dbpedianeridx, subneridx)

        featuresidx = FM(Featuresidx)

        MAX_LENGTH = len(max(trainset, key=len))

        train_X, test_X, train_features, test_features, train_extra, test_extra, train_y, test_y = x2index.sample2idx(
            trainset, testset, train_labels, test_labels, wordidx, labelidx,
            featuresidx, extraidx, args.argument)

        train_mat, test_mat, train_y, test_y = prepare.mat(
            train_X, test_X, train_y, test_y, MAX_LENGTH, train_features,
            test_features, train_extra, test_extra)

        allidx = wordidx, labelidx, featuresidx, extraidx

        # # 将类实例化成函数对象
        # # 首先，是类的实例
        # buildmodel=BuildModel()
        # # 然后，是类的建模方法与损失函数方法调用
        # build_model=buildmodel.build_model(allidx, MAX_LENGTH,
        #             args.argument, args.epochs,
        #             args.learning_rate, args.dropout, Modelpath)
        # crf=buildmodel.CRF(allidx)

        # 根据需求，训练或者加载继续训练或者测试模型的效果
        if Train_or_Load_or_Test_Model == "Train":
            # 提前设置模型的命名字符串与存储路径，以便‘Load’或‘Test’输入模型文件
            filelist = os.listdir('../Model_Save')
            modelname_config = Nug_or_Arg + '_det-' + Act + '-shuf' + Shuf + \
                               '-drop' + "".join(str(dropout).split('.')) + \
                               '-lr' + "".join(str(learning_rate).split('.')) + \
                               '-Bz' + str(Batch_size) + '-Ep' + str(Epochs)
            modelname_initial = modelname_config + '-0.h5'
            modelname = modelname_initial.split('.')[0]
            if modelname_config in filelist:
                counter = len([i for i in filelist if modelname.split('-')[:-1] in i])
                modelname_counter = int(modelname.split('-')[-1]) + counter

                modelname_final = modelname_config + '-' + str(modelname_counter) +\
                                  '-loss-categorical.h5'
            else:
                modelname_final = modelname_initial
            modelpath = '../Model_Save/' + modelname_final

            model = build_model(allidx, MAX_LENGTH,
                                args.argument, args.epochs,
                                args.learning_rate, args.dropout)
            model.fit(train_mat,
                      layers.to_categorical_word(train_y, len(labelidx)),
                      batch_size=Batch_size,
                      epochs=args.epochs,
                      validation_split=0.2,
                      shuffle=shuffle)

        elif Train_or_Load_or_Test_Model == "Load":
            # modelpath = Modelpath
            # model = load_model(Modelpath, custom_objects={'CRF':CRF, 'crf_loss':crf.loss_function})
            model = load_model(Modelpath,custom_objects={'CRF':CRF, 'crf_loss':crf.loss_function}, compile=False)
            model.compile(optimizer=Adam(learning_rate=learning_rate, loss=crf.loss_function))
            model.fit(train_mat,
                      layers.to_categorical_word(train_y, len(labelidx)),
                      batch_size=Batch_size,
                      epochs=args.epochs,
                      validation_split=0.2,
                      shuffle=shuffle)
        else:  # Train_or_Load_or_Test_Model == "Test"
            # modelpath = Modelpath
            model = load_model(Modelpath, custom_objects={'CRF':CRF, 'crf_loss':crf.loss_function})
            # model = load_model(Modelpath, compile=False, custom_objects={'CRF':CRF, 'crf_loss':CRF.loss_function})
            # model.compile(optimizer=Adam(0.00022) ,loss=[CRF.loss_function])

        scores = model.evaluate(
            test_mat, layers.to_categorical_word(test_y, len(labelidx)))

        print("************测试点：查看输出位置************")
        print("{}:{}".format(model.metrics_names[1], scores[1] * 100))

        y_pred = model.predict(test_mat)

        y_classes = y_pred.argmax(axis=-1)
        # for i in range(len(y_classes)):
        #     print(y_classes[i])
        #     print(test_y[i])
        #     print("==========")

        report.classification_multilabel_multioutput(labelidx, test_y,
                                                     y_classes)
        report.to_file_multioutput(args.outputfile, labelidx, y_pred,
                                   filechange_position, test_y, testset,
                                   y_classes)
        print()


        # 对训练效果好、准确率高于90的模型保存，保存模型的结构与训练参数文件
        if Train_or_Load_or_Test_Model == "Train" and scores[1] * 100 > 80:
            model.save(modelpath,)
            print(f"Train阶段，{modelpath}模型文件已保存！")
        elif Train_or_Load_or_Test_Model == 'Load' and scores[1] * 100 > 80:
            modelpath = Modelpath
            if 'Load' in modelpath.split('.')[0]:
                load_counter = int(modelpath.split('.')[0].split('Load')[-1])
                modelpath_update = modelpath.split('.')[0].split('Load')[0] + \
                                   'Load' + str(load_counter+1) + '.h5'
            else:
                modelpath_update = modelpath.split('.')[0] + '-Load0' + '.h5'
            model.save(modelpath_update)
            print(f"Load阶段，{modelpath_update}模型文件已保存！")


if __name__ == "__main__":
    main(sys.argv[1:],
         Train_or_Load_or_Test_Model="Train",
         Nug_or_Arg="Nug",
         Act = 'tanh',
         Shuf = 'yes',
         Epochs=100,
         Batch_size=256,
         learning_rate=0.00022,
         dropout=0.3,
         # 当加载与测试模型时，应当给出模型的路径，模型的其他超参数配置已经无效了
         Modelpath='../Model_Save/Nug_det-relu-shufyes-drop03-lr000022-Bz256-Ep100-0.h5'
         # Train_Model_Save="nug_det-relu-shufno-drop03-lr0022.h5",
         # Test_Model_Read="nug_det_savemodel_actirelu-0.h5",
        )
